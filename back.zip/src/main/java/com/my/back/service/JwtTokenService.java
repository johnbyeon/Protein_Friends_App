// 📂 src/main/java/com/my/back/service/JwtTokenService.java
package com.my.back.service;

import com.my.back.myjwt.SessionTime;
import io.jsonwebtoken.Jwts;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import javax.crypto.SecretKey;
import javax.crypto.spec.SecretKeySpec;
import java.nio.charset.StandardCharsets;
import java.util.Date;

/**
 * ==============================================================
 * 🔹 JwtTokenService — JWT 생성 및 검증 로직
 * ==============================================================
 * ✅ 주요 기능
 *  1. 비밀키(secret) 기반으로 토큰 생성
 *  2. 토큰 만료 여부 확인
 *  3. 토큰에서 이메일(email), 권한(role) 추출
 * ✅ 사용 위치
 *  - LoginFilter: 로그인 성공 시 createToken() 호출
 *  - JWTFilter: 요청 인증 시 검증 및 claim 추출
 * ==============================================================
 */
@Service
@RequiredArgsConstructor
public class JwtTokenService implements SessionTime {

    // ----------------------------------------------------------
    // ✅ application.yml → spring.jwt.secret 값 주입
    // ----------------------------------------------------------
    @Value("${spring.jwt.secret}")
    private String secret;

    // ----------------------------------------------------------
    // ✅ SecretKey 생성 (HS256 알고리즘)
    // ----------------------------------------------------------
    private SecretKey getKey() {
        // SecretKeySpec 을 통해 문자열 key → SecretKey 변환
        return new SecretKeySpec(
                secret.getBytes(StandardCharsets.UTF_8),
                Jwts.SIG.HS256.key().build().getAlgorithm()
        );
    }

    // ----------------------------------------------------------
    // ✅ 토큰 생성 (email, role, 만료시간)
    // ----------------------------------------------------------
    public String createToken(String email, String role, long expireMs) {
        return Jwts.builder()
                .claim("email", email)                           // 사용자 이메일
                .claim("role", role)                             // 권한
                .issuedAt(new Date())                            // 발급 시각
                .expiration(new Date(System.currentTimeMillis() + expireMs)) // 만료 시각
                .signWith(getKey())                              // 서명
                .compact();
    }

    // ----------------------------------------------------------
    // ✅ 토큰 만료 여부 확인
    // ----------------------------------------------------------
    public boolean isExpired(String token) {
        Date exp = Jwts.parser()
                .verifyWith(getKey()).build()
                .parseSignedClaims(token)
                .getPayload()
                .getExpiration();
        return exp.before(new Date());
    }

    // ----------------------------------------------------------
    // ✅ 토큰에서 이메일(email) 추출
    // ----------------------------------------------------------
    public String extractEmail(String token) {
        return Jwts.parser()
                .verifyWith(getKey()).build()
                .parseSignedClaims(token)
                .getPayload()
                .get("email", String.class);
    }

    // ----------------------------------------------------------
    // ✅ 토큰에서 권한(role) 추출
    // ----------------------------------------------------------
    public String extractRole(String token) {
        return Jwts.parser()
                .verifyWith(getKey()).build()
                .parseSignedClaims(token)
                .getPayload()
                .get("role", String.class);
    }
}
