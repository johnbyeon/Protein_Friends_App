package com.my.back.config;

import com.my.back.myjwt.JWTFilter;
import com.my.back.myjwt.LoginFilter;
import com.my.back.oauth2.OAuth2SuccessHandler;
import com.my.back.repository.UserRepository;
import com.my.back.service.CustomUserDetailsService;
import com.my.back.service.JwtTokenService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.HttpMethod;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.dao.DaoAuthenticationProvider;
import org.springframework.security.config.Customizer;
import org.springframework.security.config.annotation.authentication.builders.AuthenticationManagerBuilder;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.http.SessionCreationPolicy;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.web.SecurityFilterChain;
import org.springframework.security.web.authentication.UsernamePasswordAuthenticationFilter;
import org.springframework.web.cors.CorsConfiguration;
import org.springframework.web.cors.CorsConfigurationSource;
import org.springframework.web.cors.UrlBasedCorsConfigurationSource;

import jakarta.servlet.http.HttpServletResponse;
import java.util.List;

@Slf4j
@Configuration
@EnableWebSecurity
@RequiredArgsConstructor
public class SecurityConfig {

    // ==============================================================
    // 🔹 의존성 주입
    // ==============================================================
    private final JwtTokenService jwtTokenService;             // JWT 생성·검증 서비스
    private final UserRepository userRepository;               // 로그인 사용자 조회용
    private final CustomUserDetailsService customUserDetailsService; // UserDetailsService 구현체
    private final OAuth2SuccessHandler oAuth2SuccessHandler;   // (현재 비활성화 상태)
    private final JWTFilter jwtFilter;                         // JWT 검증 필터 (OncePerRequestFilter 상속)

    // ==============================================================
    // 🔹 비밀번호 암호화기 (BCrypt)
    // ==============================================================
    @Bean
    public PasswordEncoder passwordEncoder() {
        return new BCryptPasswordEncoder();
    }

    // ==============================================================
    // 🔹 AuthenticationManager 등록
    // - UsernamePasswordAuthenticationFilter 가 사용할 인증 매니저
    // ==============================================================
    @Bean
    public AuthenticationManager authenticationManager(HttpSecurity http) throws Exception {
        AuthenticationManagerBuilder builder = http.getSharedObject(AuthenticationManagerBuilder.class);
        DaoAuthenticationProvider provider = new DaoAuthenticationProvider();
        provider.setUserDetailsService(customUserDetailsService);
        provider.setPasswordEncoder(passwordEncoder());
        builder.authenticationProvider(provider);
        return builder.build();
    }

    // ==============================================================
    // 🔹 핵심 보안 설정 (FilterChain)
    // ==============================================================
    @Bean
    public SecurityFilterChain securityFilterChain(HttpSecurity http, AuthenticationManager authManager) throws Exception {
        log.info("✅ SecurityFilterChain initialized — filter order starting...");

        // ----------------------------------------------------------
        // ✅ 로그인 필터 등록 (/api/auth/login)
        // - JSON 바디(email, password) 기반 로그인 처리
        // - 성공 시 JWT 토큰 발급
        // ----------------------------------------------------------
        LoginFilter loginFilter = new LoginFilter(authManager, jwtTokenService, userRepository);
        loginFilter.setFilterProcessesUrl("/api/auth/login");

        // ----------------------------------------------------------
        // ✅ Security 설정 시작
        // ----------------------------------------------------------
        http
                // 🔸 1) CSRF 비활성화 (REST API는 필요 없음)
                .csrf(csrf -> csrf.disable())

                // 🔸 2) CORS 설정 (프론트 요청 허용)
                .cors(Customizer.withDefaults())

                // 🔸 3) 세션 비활성화 — 완전한 Stateless 환경
                .sessionManagement(sm -> sm.sessionCreationPolicy(SessionCreationPolicy.STATELESS))

                // 🔸 4) 폼 로그인 / HTTP Basic 로그인 비활성화
                //      → JSON API만 사용하기 때문에 브라우저 리다이렉트 방지
                .formLogin(fl -> fl.disable())
                .httpBasic(hb -> hb.disable())

                // 🔸 5) 인증 실패 시 401 JSON 반환 (기본 redirect 방지)
                .exceptionHandling(eh -> eh.authenticationEntryPoint((req, res, ex) -> {
                    res.setStatus(HttpServletResponse.SC_UNAUTHORIZED);
                    res.setContentType("application/json;charset=UTF-8");
                    res.getWriter().write("{\"error\":\"unauthorized\"}");
                }))

                // 🔸 6) 요청별 접근 제어
                .authorizeHttpRequests(auth -> auth
                        // ✅ 로그인/회원가입 등 공개 API 허용
                        .requestMatchers(HttpMethod.POST,
                                "/api/auth/login",
                                "/api/auth/join"
                        ).permitAll()

                        // ✅ 상태확인·에러 페이지 등 허용
                        .requestMatchers(
                                "/actuator/health",
                                "/error"
                        ).permitAll()

                        // ✅ 그 외 모든 요청은 인증 필요
                        .anyRequest().authenticated()
                )

                // 🔸 7) OAuth2 로그인 (현재 비활성화) → 302 방지
                .oauth2Login(o -> o.disable())

                // 🔸 8) 필터 등록 순서
                // [LoginFilter] : /api/auth/login 요청 시 실행 → 토큰 발급
                // [JWTFilter]   : 모든 요청 시 토큰 검증 → SecurityContext 에 유저정보 저장
                .addFilterBefore(jwtFilter, UsernamePasswordAuthenticationFilter.class)
                .addFilterAt(loginFilter, UsernamePasswordAuthenticationFilter.class);

        // ----------------------------------------------------------
        // ✅ 최종 체인 반환
        // ----------------------------------------------------------
        return http.build();
    }

    // ==============================================================
    // 🔹 CORS 설정 (React / Vite 프론트와 통신 허용)
    // ==============================================================
    @Bean
    public CorsConfigurationSource corsConfigurationSource() {
        CorsConfiguration c = new CorsConfiguration();

        // 허용 Origin
        c.setAllowedOriginPatterns(List.of(
                "http://localhost:*",
                "http://localhost:3000",
                "https://proteinfriends.shop",
                "https://www.proteinfriends.shop"
        ));

        // 허용 메서드
        c.setAllowedMethods(List.of("GET","POST","PUT","PATCH","DELETE","OPTIONS"));

        // 허용 헤더 및 노출 헤더
        c.setAllowedHeaders(List.of("*"));
        c.setExposedHeaders(List.of("Authorization","Set-Cookie"));

        // 쿠키 및 인증정보 포함 요청 허용
        c.setAllowCredentials(true);

        // 전역 경로 등록
        UrlBasedCorsConfigurationSource src = new UrlBasedCorsConfigurationSource();
        src.registerCorsConfiguration("/**", c);
        return src;
    }
}
