package com.my.back.repository;

import com.my.back.entity.Users;
import org.springframework.data.jpa.repository.EntityGraph;
import org.springframework.data.jpa.repository.JpaRepository;

/**
 * Users 엔티티용 레포지토리 (팀장 코드 호환 수정판)
 * -----------------------------------------------------
 * - 이메일로 단건 조회 시 Optional 제거 (직접 Users 반환)
 * - 인포(UserInfo), 소셜(SocialAccount)까지 한 번에 로딩 가능
 * -----------------------------------------------------
 */
public interface UserRepository extends JpaRepository<Users, Long> {

    /** 이메일 중복 여부 */
    boolean existsByEmail(String email);

    /** Users 엔티티만 단건 조회 (Optional → Users 로 단순화) */
    Users findByEmail(String email);

    /**
     * Users + userInfo + socialAccounts 를 한 번에 로딩
     * - OAuth2 로그인 및 MyInfoService용
     */
    @EntityGraph(attributePaths = {"userInfo", "socialAccounts"})
    Users findWithUserInfoAndSocialAccountsByEmail(String email);
}
