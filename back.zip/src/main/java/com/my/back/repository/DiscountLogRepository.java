package com.my.back.repository;

import com.my.back.entity.DiscountLog;
import org.springframework.data.jpa.repository.EntityGraph;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import java.util.List;

/**
 * 할인권 로그 Repository
 * - 회원이 보유한 할인권 내역을 조회
 */
@Repository
public interface DiscountLogRepository extends JpaRepository<DiscountLog, Long> {

    /**
     * 회원 고유번호(u_id)로 할인권 목록 조회
     * DiscountService를 함께 즉시 로딩(fetch join)하여
     * N+1 문제를 방지한다.
     */
    @EntityGraph(attributePaths = {"discountService"})
    List<DiscountLog> findByUsers_uId(Long uId);
}
