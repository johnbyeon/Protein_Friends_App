// 📂 src/main/java/com/my/back/myjwt/JWTFilter.java
package com.my.back.myjwt;

import com.my.back.service.JwtTokenService;
import jakarta.servlet.FilterChain;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.web.authentication.WebAuthenticationDetailsSource;
import org.springframework.stereotype.Component;
import org.springframework.web.filter.OncePerRequestFilter;

import java.io.IOException;
import java.util.List;

// ✅ [CHANGED-IMPORT] principal 을 UserDetails 로 세팅하기 위해 추가
import org.springframework.security.core.userdetails.User; // <-- 추가

/**
 * ==============================================================
 * 🔹 JWT 인증 필터 (OncePerRequestFilter)
 * ==============================================================
 * - 모든 요청(Request)에 대해 1회 실행됨
 * - Authorization 헤더에서 Bearer 토큰 추출
 * - JwtTokenService 로 서명/만료 검증
 * - 유효할 경우 principal(UserDetails.username=email) + role(SecurityContext)에 등록
 * - ✅ @AuthenticationPrincipal(expression = "username") 로 email 주입 보장
 * ==============================================================
 */
@Slf4j
@Component
@RequiredArgsConstructor
public class JWTFilter extends OncePerRequestFilter {

    private final JwtTokenService jwtTokenService;  // JWT 파싱 및 검증 서비스

    // ----------------------------------------------------------
    // ✅ 1) 인증이 필요 없는 엔드포인트(로그인, 회원가입 등) 목록
    // ----------------------------------------------------------
    private boolean shouldBypass(HttpServletRequest request) {
        String p = request.getRequestURI();
        return p.startsWith("/api/auth/login")
                || p.startsWith("/api/auth/join")
                || p.startsWith("/oauth2/authorization")   // 소셜 로그인 시작
                || p.startsWith("/login/oauth2/code")       // 소셜 콜백
                || p.startsWith("/oauth2/callback")         // 커스텀 리다이렉트
                || p.equals("/error")
                || p.startsWith("/actuator");
    }

    // ----------------------------------------------------------
    // ✅ 2) 필터 핵심 로직
    // ----------------------------------------------------------
    @Override
    protected void doFilterInternal(HttpServletRequest request,
                                    HttpServletResponse response,
                                    FilterChain filterChain)
            throws IOException, ServletException {

        String path = request.getRequestURI();
        String method = request.getMethod();

        // 🔸 (1) 인증 예외 URI 는 필터 스킵
        if (shouldBypass(request)) {
            log.info("[JWTFilter] ⏩ Bypass URI: {}", path);
            filterChain.doFilter(request, response);
            return;
        }

        log.info("➡️ [JWTFilter] {} {}", method, path);
        String authorization = request.getHeader("Authorization");
        log.info("🔍 Authorization Header = {}", authorization);

        // 🔸 (2) Authorization 헤더 없거나 형식 오류면 스킵
        if (authorization == null || !authorization.startsWith("Bearer ")) {
            log.warn("🚫 [JWTFilter] Authorization 헤더 누락 or 형식 오류");
            filterChain.doFilter(request, response);
            return;
        }

        // 🔸 (3) Bearer 제거 후 JWT 추출
        String token = authorization.substring(7).trim();
        log.info("🔹 [JWTFilter] Token = {}", token);

        try {
            // ======================================================
            // 🔹 JWT 검증 단계
            // ======================================================
            boolean expired = jwtTokenService.isExpired(token);
            log.info("🔹 [JWTFilter] Token 만료 여부 = {}", expired);

            if (expired) {
                log.warn("⚠️ [JWTFilter] JWT 만료됨 — 다음 필터로 진행");
                filterChain.doFilter(request, response);
                return;
            }

            // 🔹 토큰에서 이메일, 권한 클레임 추출
            String email   = jwtTokenService.extractEmail(token);
            String rawRole = jwtTokenService.extractRole(token); // "USER" or "ROLE_USER"
            log.info("🔹 [JWTFilter] 추출된 클레임 → email={}, role={}", email, rawRole);

            if (email == null) {
                log.error("❌ [JWTFilter] email 클레임 누락됨 — 인증 처리 생략");
                filterChain.doFilter(request, response);
                return;
            }

            // ======================================================
            // 🔹 SecurityContext 에 Authentication 세팅
            // ======================================================
            String normalizedRole = normalizeRole(rawRole);

            // ✅ [CHANGED] principal 을 문자열이 아닌 UserDetails 로 세팅
            //    → @AuthenticationPrincipal(expression="username") 가 정상 동작
            User principalUser = new User(                  // <-- 변경
                    email,                                  // username
                    "",                                     // password(불필요)
                    List.of(new SimpleGrantedAuthority(normalizedRole))
            );

            // ✅ [CHANGED] principalUser 로 Authentication 생성
            UsernamePasswordAuthenticationToken authToken =  // <-- 변경
                    new UsernamePasswordAuthenticationToken(
                            principalUser,                   // principal = UserDetails
                            null,
                            principalUser.getAuthorities()
                    );

            authToken.setDetails(new WebAuthenticationDetailsSource().buildDetails(request));
            SecurityContextHolder.getContext().setAuthentication(authToken);

            log.info("✅ [JWTFilter] SecurityContext 세팅 완료 - Principal(UserDetails.username)={}", email);

        } catch (Exception e) {
            log.error("❌ [JWTFilter] JWT 처리 중 예외 발생", e);
        }

        // 🔸 (4) 체인 다음 필터로 전달
        filterChain.doFilter(request, response);

        // 🔹 디버그 로그
        Authentication auth = SecurityContextHolder.getContext().getAuthentication();
        log.info("🟢 [JWTFilter] 필터 종료 후 Authentication 존재 여부: {}", (auth != null));
        if (auth != null)
            log.info("🟢 [JWTFilter] Principal 타입: {}, 값: {}",
                    auth.getPrincipal().getClass().getSimpleName(),
                    auth.getPrincipal());
    }

    // ----------------------------------------------------------
    // ✅ 3) 역할 문자열 정규화 ("USER" → "ROLE_USER")
    // ----------------------------------------------------------
    private String normalizeRole(String raw) {
        if (raw == null || raw.isBlank()) return "ROLE_USER";
        String r = raw.trim().toUpperCase();
        return r.startsWith("ROLE_") ? r : "ROLE_" + r;
    }
}
