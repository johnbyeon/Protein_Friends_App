// 📂 src/main/java/com/my/back/myjwt/LoginFilter.java
package com.my.back.myjwt;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.my.back.entity.Users;
import com.my.back.repository.UserRepository;
import com.my.back.service.JwtTokenService;
import jakarta.servlet.FilterChain;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import lombok.extern.slf4j.Slf4j;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.web.authentication.UsernamePasswordAuthenticationFilter;
import org.springframework.util.StringUtils;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.HashMap;
import java.util.Map;
import java.util.Objects;

/**
 * ==============================================================
 * 🔹 LoginFilter (JSON 로그인 전용)
 * ==============================================================
 * - 엔드포인트: /api/auth/login
 * - 요청 본문: { "email": "...", "password": "..." }
 * - 인증 성공: JWT 발급 + 사용자 일부 정보 동봉
 * - 인증 실패: 401 JSON (리다이렉트 없음)
 * - 주의: SecurityConfig 에서 addFilterAt(...) 으로 체인에 등록 필요
 * ==============================================================
 */
@Slf4j
public class LoginFilter extends UsernamePasswordAuthenticationFilter implements SessionTime {

    // ----------------------------------------------------------
    // ✅ 의존성
    // ----------------------------------------------------------
    private final ObjectMapper objectMapper = new ObjectMapper();
    private final JwtTokenService jwtTokenService;
    private final UserRepository userRepository;

    // ----------------------------------------------------------
    // ✅ 생성자
    //  - AuthenticationManager 주입 (부모 필터가 사용)
    //  - 처리 URL 고정: /api/auth/login
    // ----------------------------------------------------------
    public LoginFilter(AuthenticationManager authenticationManager,
                       JwtTokenService jwtTokenService,
                       UserRepository userRepository) {
        this.jwtTokenService = Objects.requireNonNull(jwtTokenService);
        this.userRepository = Objects.requireNonNull(userRepository);
        // 부모 필터에 AuthenticationManager 주입 (NPE 방지)
        super.setAuthenticationManager(Objects.requireNonNull(authenticationManager));
        // 프런트에서 호출하는 엔드포인트와 반드시 일치
        super.setFilterProcessesUrl("/api/auth/login");
    }

    // ----------------------------------------------------------
    // ✅ 시도: 본문 파싱 → Authentication 생성 → 인증 매니저 위임
    // ----------------------------------------------------------
    @Override
    public org.springframework.security.core.Authentication attemptAuthentication(
            HttpServletRequest request, HttpServletResponse response) {

        log.info("🟢 [LoginFilter] attemptAuthentication() url={} contentType={} method={}",
                request.getRequestURI(), request.getContentType(), request.getMethod());

        try {
            String contentType = request.getContentType();
            String email;
            String password;

            // 1) JSON 바디 우선 처리
            if (contentType != null && contentType.toLowerCase().contains("application/json")) {
                LoginRequest body = objectMapper.readValue(request.getInputStream(), LoginRequest.class);
                email = body.email == null ? "" : body.email.trim();
                password = body.password == null ? "" : body.password;
            } else {
                // 2) 폼 전송도 허용 (Fallback)
                email = StringUtils.hasText(request.getParameter("email")) ? request.getParameter("email") : "";
                password = StringUtils.hasText(request.getParameter("password")) ? request.getParameter("password") : "";
            }

            if (!StringUtils.hasText(email) || !StringUtils.hasText(password)) {
                throw new BadCredentialsException("이메일/비밀번호를 확인해주세요.");
            }

            // UsernamePasswordAuthenticationToken 생성 후 인증 시도
            UsernamePasswordAuthenticationToken authRequest =
                    new UsernamePasswordAuthenticationToken(email, password);
            setDetails(request, authRequest);

            return this.getAuthenticationManager().authenticate(authRequest);

        } catch (Exception e) {
            // ❗ 예외 발생 시 401 JSON 으로 응답(500 방지)
            log.warn("⚠️ [LoginFilter] attemptAuthentication error: {}", e.getMessage(), e);
            try {
                unsuccessfulAuthentication(
                        request, response,
                        new BadCredentialsException("로그인 요청이 올바르지 않습니다.", e)
                );
            } catch (IOException io) {
                log.error("❌ [LoginFilter] unsuccessfulAuthentication write error", io);
            }
            return null; // 체인은 진행되지만 응답은 401로 이미 종료
        }
    }

    // ----------------------------------------------------------
    // ✅ 성공: JWT 생성 → JSON 응답 (access_token, 만료, 사용자 요약)
    // ----------------------------------------------------------
    @Override
    protected void successfulAuthentication(HttpServletRequest request,
                                            HttpServletResponse response,
                                            FilterChain chain,
                                            org.springframework.security.core.Authentication authResult) throws IOException {
        try {
            log.info("🟢 [LoginFilter] successfulAuthentication() principal={}",
                    authResult != null ? authResult.getName() : "null");

            if (authResult == null) {
                throw new IllegalStateException("Authentication result is null");
            }

            // 인증 주체: 이메일
            String email = authResult.getName();

            // 권한 추출 (첫 번째 권한 기준, ROLE_ prefix 제거)
            String role = "USER";
            var authorities = authResult.getAuthorities();
            if (authorities != null && !authorities.isEmpty()) {
                String got = authorities.iterator().next().getAuthority(); // e.g. "ROLE_USER" or "USER"
                if (got != null && !got.isBlank()) {
                    role = got.startsWith("ROLE_") ? got.substring(5) : got;
                }
            }
            log.info("🟢 resolved role = {}", role);

            // JWT 생성 (HOUR 은 SessionTime 인터페이스에서 제공되는 만료 밀리초)
            String token = jwtTokenService.createToken(email, role, HOUR);
            int expiresInSec = (int) (HOUR / 1000);

            // 유저 조회(프로필 작성 필요 여부 계산)
            Users user = userRepository.findByEmail(email);
            boolean needProfile = user == null
                    || user.getName() == null || user.getName().isBlank()
                    || user.getPhone() == null || user.getPhone().isBlank();

            // 사용자 정보 페이로드 최소화 (프런트 초기 세션 구성용)
            Map<String, Object> userJson = new HashMap<>();
            userJson.put("email", email);
            userJson.put("role", role);
            userJson.put("name", user != null ? user.getName() : null);
            userJson.put("phone", user != null ? user.getPhone() : null);

            Map<String, Object> payload = new HashMap<>();
            payload.put("access_token", token);
            payload.put("expires_in", expiresInSec);
            payload.put("user", userJson);
            payload.put("need_profile", needProfile);

            String jsonResponse = objectMapper.writeValueAsString(payload);
            log.info("🟩 [LoginFilter] 응답 JSON = {}", jsonResponse);

            // 헤더와 바디 동시 제공 (일부 클라이언트 호환 목적)
            response.setStatus(HttpServletResponse.SC_OK);
            response.setHeader("Authorization", "Bearer " + token);
            response.setContentType("application/json;charset=UTF-8");
            response.getWriter().write(jsonResponse);
            response.getWriter().flush();

        } catch (Exception e) {
            // ❗ 성공 처리 중 예외가 나도 500 방지 → 401 로 다운그레이드
            log.error("❌ [LoginFilter] successfulAuthentication 처리 중 예외: {}", e.getMessage(), e);
            response.setStatus(HttpServletResponse.SC_UNAUTHORIZED);
            response.setContentType("application/json;charset=UTF-8");
            var err = Map.of(
                    "error", "로그인 처리 중 오류가 발생했습니다.",
                    "detail", e.getClass().getSimpleName()
            );
            response.getWriter().write(objectMapper.writeValueAsString(err));
            response.getWriter().flush();
        }
    }

    // ----------------------------------------------------------
    // ❌ 실패: 401 JSON 반환 (리다이렉트 금지)
    // ----------------------------------------------------------
    @Override
    protected void unsuccessfulAuthentication(HttpServletRequest request,
                                              HttpServletResponse response,
                                              org.springframework.security.core.AuthenticationException failed)
            throws IOException {
        response.setStatus(HttpServletResponse.SC_UNAUTHORIZED);
        response.setContentType("application/json;charset=UTF-8");
        try (PrintWriter out = response.getWriter()) {
            Map<String, Object> err = Map.of(
                    "error", "아이디 또는 비밀번호가 올바르지 않습니다."
            );
            out.print(objectMapper.writeValueAsString(err));
        }
    }

    // ----------------------------------------------------------
    // 🔹 JSON 바디 파싱용 DTO (record 아닌 기본 클래스로 호환성 유지)
    // ----------------------------------------------------------
    public static final class LoginRequest {
        public String email;
        public String password;
        public LoginRequest() {}
    }
}
